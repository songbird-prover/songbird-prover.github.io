#!/bin/bash
export LC_ALL=C

SB=./sls
OPT=""
STAT=""
SUITE=""
LOG=""
PID=$$
out=$PWD/out.txt
time=$PWD/out.time.txt

# printing function
log_res () {
  printf "$1"
  if [[ ! -z $LOG ]]; then
    printf "$1" >> $LOG
  fi
}

list_descendants () {
  local children=$(ps -o pid= --ppid "$1")

  for pid in $children
  do
    list_descendants "$pid"
  done

  echo "$children"
}

trap 'echo "";\
      echo Terminating process due to CTRL-C; \
      echo Kill child processes;\
      pkill -TERM -P $PID;\
      exit' INT

echo "My PID is $PID"

while [[ $# > 0 ]]
do
  key="$1"

  case $key in
    -b|--bench)
      SUITE="$2"
      shift # past argument
    ;;
    -o|--option)
      OPT=$OPT"$2 "
      shift # past argument
    ;;
    -s|--stat)
      STAT="$1"
    ;;
    -l|--log)
      LOG="$2"
      # shift # past argument
    ;;
    *) # unknown option
    ;;
  esac
  shift # past argument or value
done

echo "Evaluating the benchmark $SUITE"

[[ ! -z $OPT ]] && echo "Running SLS with $OPT"

if [[ ! -z $LOG ]]; then
  echo "Running SLS with benchmark: $SUITE" > $LOG
  echo "" >> $LOG
  echo "Output is written to the log file: $LOG"
  echo ""
fi

if [[ ! -z $STAT ]]; then
    log_res "Testcase \tResult \tTime \tNumAllLemmas \tNumUsedLemmas \tTimeAllLemmas \tNumUsedConvert \tNumAppConvert \tNumUsedSplit \tNumAppSplit \tNumUsedCombine \tNumAppCombine \n"
else
    log_res "Testcase \tResult \tTime \n"
fi

for fc in $PWD/benchmarks/$SUITE/*.sb; do
  filename=$(basename "$fc")
  filename="${filename%.*}"

  log_res "$filename \t"
  (cd sls-prover && timeout 180 /usr/bin/time -f "%e" $SB $fc $OPT 1>$out 2>$time)

  if [ "$?" -eq 124 ]; then
    log_res "TIMEOUT"
  else
    if grep -q "Valid" $out; then
      res="Valid"
      
      # run time
      runtime=`grep -Po '(?<=Time: ).*' $out`   # read time from output
      runtime="$(echo "$runtime" | sed -e 's/(s)//g')"
      runtime="$(echo "$runtime" | tr -d ' ')"
      printf -v runtime %.2f "$runtime"
      
      # stats
      if [[ ! -z $STAT ]]; then
        all_lm=`grep -Po '(?<=Number of lemmas inferred: ).*' $out`
        all_lm="$(echo "$all_lm" | tr -d ' ')"
        used_lm=`grep -Po '(?<=Number of lemmas used: ).*' $out`
        used_lm="$(echo "$used_lm" | tr -d ' ')"
        runtime_lm=`grep -Po '(?<=Runtime \(in seconds\) to infer all lemmas: ).*' $out`
        runtime_lm="$(echo "$runtime_lm" | tr -d ' ')"
        
        convert_used=`grep -Po '(?<=Lemma-convert used: ).*' $out`
        convert_used="$(echo "$convert_used" | tr -d ' ')"
        convert_app=`grep -Po '(?<=Lemma-convert using times: ).*' $out`
        convert_app="$(echo "$convert_app" | tr -d ' ')"
        
        split_used=`grep -Po '(?<=Lemma-split used: ).*' $out`
        split_used="$(echo "$split_used" | tr -d ' ')"
        split_app=`grep -Po '(?<=Lemma-split using times: ).*' $out`
        split_app="$(echo "$split_app" | tr -d ' ')"
        
        combine_used=`grep -Po '(?<=Lemma-combine used: ).*' $out`
        combine_used="$(echo "$combine_used" | tr -d ' ')"
        combine_app=`grep -Po '(?<=Lemma-combine using times: ).*' $out`
        combine_app="$(echo "$combine_app" | tr -d ' ')"

        log_res "$res \t$runtime \t$all_lm \t$used_lm \t$runtime_lm \t$convert_used \t$convert_app \t$split_used \t$split_app \t$combine_used \t$combine_app"
      else
        log_res "$res \t$runtime"
      fi
    elif grep -q -i -E 'Exception|Error' $out; then
      log_res "ERR"
    else 
      log_res "UNK"
    fi
  fi
  log_res "\n"
done;
